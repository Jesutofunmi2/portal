<script language="javascript">
	window.location = "../index.php";
</script>